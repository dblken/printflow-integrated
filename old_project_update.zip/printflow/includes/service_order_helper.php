<?php
/**
 * Service Order Helper
 * PrintFlow - Shared logic for service-based ordering
 * - Secure file upload (JPG, PNG, PDF, max 5MB)
 * - Insert order, order_details, order_files
 * - Uses prepared statements
 */

if (!defined('BASE_URL')) define('BASE_URL', '/printflow');

// Allowed file types for uploads
define('SERVICE_ORDER_ALLOWED_TYPES', ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf']);
define('SERVICE_ORDER_MAX_SIZE', 5 * 1024 * 1024); // 5MB
define('SERVICE_ORDER_UPLOAD_DIR', __DIR__ . '/../uploads/orders/');

/**
 * Ensure upload directory exists and is writable
 * @return bool
 */
function service_order_ensure_upload_dir() {
    $dir = SERVICE_ORDER_UPLOAD_DIR;
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    return is_writable($dir);
}

/**
 * Validate uploaded file
 * @param array $file $_FILES['field_name']
 * @return array ['ok' => bool, 'error' => string]
 */
function service_order_validate_file($file) {
    if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'error' => 'Please select a file to upload.'];
    }
    if ($file['size'] > SERVICE_ORDER_MAX_SIZE) {
        return ['ok' => false, 'error' => 'File size exceeds 5MB limit.'];
    }
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    if (!in_array($mime, SERVICE_ORDER_ALLOWED_TYPES)) {
        return ['ok' => false, 'error' => 'Invalid file type. Allowed: JPG, PNG, PDF.'];
    }
    return ['ok' => true, 'error' => ''];
}

/**
 * Save uploaded file and return relative path for DB
 * @param array $file $_FILES['field_name']
 * @param int $order_id
 * @param string $prefix e.g. 'design', 'reference'
 * @return array ['path' => string, 'error' => string]
 */
function service_order_save_file($file, $order_id, $prefix = 'file') {
    if (!service_order_ensure_upload_dir()) {
        return ['path' => '', 'error' => 'Upload directory not writable.'];
    }
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'pdf'])) {
        $ext = 'bin';
    }
    $filename = $prefix . '_' . $order_id . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $full_path = SERVICE_ORDER_UPLOAD_DIR . $filename;
    if (!move_uploaded_file($file['tmp_name'], $full_path)) {
        return ['path' => '', 'error' => 'Failed to save file.'];
    }
    return ['path' => 'uploads/orders/' . $filename, 'original' => $file['name'], 'error' => ''];
}

/**
 * Insert service order and details
 * @param string $service_name
 * @param int $customer_id
 * @param array $fields Associative array of field_name => field_value
 * @param array $files Optional array of ['file' => $_FILES['x'], 'prefix' => 'design']
 * @return array ['success' => bool, 'order_id' => int, 'error' => string]
 */
function service_order_create($service_name, $customer_id, $fields, $files = []) {
    global $conn;
    
    // Ensure service_orders table exists
    service_order_ensure_tables();
    
    // Insert main order
    $total_price = isset($fields['total_price']) ? (float)$fields['total_price'] : 0;
    unset($fields['total_price']);
    
    $sql = "INSERT INTO service_orders (service_name, customer_id, status, total_price) VALUES (?, ?, 'Pending Review', ?)";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return ['success' => false, 'order_id' => 0, 'error' => 'Database error.'];
    }
    $stmt->bind_param('sid', $service_name, $customer_id, $total_price);
    if (!$stmt->execute()) {
        return ['success' => false, 'order_id' => 0, 'error' => 'Failed to create order.'];
    }
    $order_id = (int)$conn->insert_id;
    $stmt->close();
    
    // Insert order details (field_name, field_value)
    $detailStmt = $conn->prepare("INSERT INTO service_order_details (order_id, field_name, field_value) VALUES (?, ?, ?)");
    if (!$detailStmt) {
        return ['success' => true, 'order_id' => $order_id, 'error' => '']; // Order created, details failed
    }
    foreach ($fields as $name => $value) {
        if ($name === '' || $value === null) continue;
        $val = is_array($value) ? json_encode($value) : (string)$value;
        $detailStmt->bind_param('iss', $order_id, $name, $val);
        $detailStmt->execute();
    }
    $detailStmt->close();
    
    // Handle file uploads
    foreach ($files as $f) {
        $upload = $f['file'];
        $prefix = $f['prefix'] ?? 'file';
        $valid = service_order_validate_file($upload);
        if (!$valid['ok']) continue; // Skip invalid, don't fail entire order
        $saved = service_order_save_file($upload, $order_id, $prefix);
        if ($saved['path']) {
            $fileStmt = $conn->prepare("INSERT INTO service_order_files (order_id, file_path, original_name) VALUES (?, ?, ?)");
            if ($fileStmt) {
                $orig = $saved['original'] ?? '';
                $fileStmt->bind_param('iss', $order_id, $saved['path'], $orig);
                $fileStmt->execute();
                $fileStmt->close();
            }
        }
    }
    
    return ['success' => true, 'order_id' => $order_id, 'error' => ''];
}

/**
 * Ensure service order tables exist (auto-create if missing)
 */
function service_order_ensure_tables() {
    static $done = false;
    if ($done) return;
    global $conn;
    $conn->query("CREATE TABLE IF NOT EXISTS service_orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        service_name VARCHAR(100) NOT NULL,
        customer_id INT NOT NULL,
        status VARCHAR(50) NOT NULL DEFAULT 'Pending Review',
        total_price DECIMAL(12,2) DEFAULT 0.00,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        KEY idx_status (status),
        KEY idx_customer (customer_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $conn->query("CREATE TABLE IF NOT EXISTS service_order_details (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_id INT NOT NULL,
        field_name VARCHAR(100) NOT NULL,
        field_value TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        KEY idx_order (order_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $conn->query("CREATE TABLE IF NOT EXISTS service_order_files (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_id INT NOT NULL,
        file_path VARCHAR(255) NOT NULL,
        original_name VARCHAR(255) DEFAULT NULL,
        uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        KEY idx_order (order_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $done = true;
}
