<?php
/**
 * Customer Order Creation / Product Details Page
 * PrintFlow - Printing Shop PWA
 */

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

require_role('Customer');

$product_id = $_GET['product_id'] ?? 0;
$product = null;

if ($product_id) {
    $result = db_query("SELECT * FROM products WHERE product_id = ? AND status = 'Activated'", 'i', [$product_id]);
    if (!empty($result)) {
        $product = $result[0];
    }
}

if (!$product) {
    // Product not found or not activated
    header("Location: products.php");
    exit;
}

// Handle Add to Cart / Buy Now
$error_msg = '';
$success_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['add_to_cart']) || isset($_POST['buy_now']))) {
    $quantity = (int)$_POST['quantity'];
    
    // File Upload handling
    $design_file = '';
    if (isset($_FILES['design_upload']) && $_FILES['design_upload']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['design_upload']['tmp_name'];
        $file_name = $_FILES['design_upload']['name'];
        $file_size = $_FILES['design_upload']['size'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        $allowed = ['jpg', 'jpeg', 'png', 'pdf'];
        
        if (!in_array($file_ext, $allowed)) {
            $error_msg = "Invalid file type. Only JPG, PNG, and PDF allowed.";
        } elseif ($file_size > 5 * 1024 * 1024) { // 5MB
            $error_msg = "File too large. Max size is 5MB.";
        } else {
            $new_filename = uniqid('order_', true) . '.' . $file_ext;
            $upload_path = __DIR__ . '/../uploads/orders/' . $new_filename;
            
            if (move_uploaded_file($file_tmp, $upload_path)) {
                $design_file = $new_filename;
            } else {
                $error_msg = "Failed to upload design.";
            }
        }
    }

    // Collect customization data (everything except system fields)
    $customization = [];
    $system_fields = ['add_to_cart', 'buy_now', 'quantity', 'product_id', 'csrf_token'];
    foreach ($_POST as $key => $value) {
        if (!in_array($key, $system_fields)) {
            $customization[$key] = sanitize($value);
        }
    }

    if (empty($error_msg) && $quantity > 0) {
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        // We use a unique key for each line item to support multiple customizations of the same product
        $item_key = $product_id . '_' . time();
        
        $_SESSION['cart'][$item_key] = [
            'product_id' => $product_id,
            'name' => $product['name'],
            'price' => $product['price'],
            'quantity' => $quantity,
            'image' => '📦',
            'customization' => $customization,
            'design_file' => $design_file
        ];
        
        // Redirect to cart or checkout
        if (isset($_POST['buy_now'])) {
            header("Location: checkout.php");
        } else {
            header("Location: cart.php");
        }
        exit;
    }
}

$page_title = $product['name'] . ' - PrintFlow';
$use_customer_css = true;
require_once __DIR__ . '/../includes/header.php';
?>

<div class="min-h-screen py-8">
    <div class="container mx-auto px-4" style="max-width:1100px;">
        <a href="products.php" class="back-link" style="display:inline-flex; align-items:center; gap:6px; color:#6b7280; margin-bottom:1rem; text-decoration:none;">← Back to Products</a>

        <div class="card" style="display:grid; grid-template-columns: 1fr 1fr; gap:2rem; padding:2rem;">
            <!-- Product Image Area -->
            <div style="background:#f3f4f6; border-radius:12px; display:flex; align-items:center; justify-content:center; min-height:400px; font-size:5rem;">
                📦
            </div>

            <!-- Product Details -->
            <div>
                <h1 class="ct-page-title" style="margin-top:0.5rem; margin-bottom:1rem;"><?php echo htmlspecialchars($product['name']); ?></h1>
                
                <div style="font-size:2rem; font-weight:700; color:#1f2937; margin-bottom:1.5rem;">
                    <?php echo format_currency($product['price']); ?>
                </div>

                <div style="margin-bottom:2rem; color:#4b5563; line-height:1.6;">
                    <?php echo nl2br(htmlspecialchars($product['description'])); ?>
                </div>
                
                <?php if ($product['stock_quantity'] > 0): ?>
                    <?php if ($error_msg): ?>
                        <div style="background:#fef2f2; border:1px solid #fecaca; color:#b91c1c; padding:12px; border-radius:8px; margin-bottom:1.5rem; font-size:0.9rem;">
                            ⚠️ <?php echo htmlspecialchars($error_msg); ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" enctype="multipart/form-data" id="customization-form" style="margin-top:2rem;" x-data="{ 
                        category: '<?php echo $product['category']; ?>',
                        isValid: false,
                        validate() {
                            const form = document.getElementById('customization-form');
                            this.isValid = form.checkValidity();
                        }
                    }" @change="validate()" @input="validate()" x-init="validate()">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                        
                        <!-- Customization Fields Section -->
                        <div style="background:#f9fafb; border:1px solid #f3f4f6; border-radius:12px; padding:1.5rem; margin-bottom:2rem;">
                            <h3 style="font-size:1rem; font-weight:700; color:#374151; margin-bottom:1.5rem; display:flex; align-items:center; gap:8px;">
                                🛠️ Customization Details
                            </h3>

                            <div class="service-fields">
                                <?php 
                                $cat = $product['category'];
                                ?>

                                <?php if ($cat === 'Tarpaulin Printing'): ?>
                                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem; margin-bottom:1rem;">
                                        <div>
                                            <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Width (ft) *</label>
                                            <input type="number" name="width" required class="input-field" placeholder="e.g. 2">
                                        </div>
                                        <div>
                                            <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Height (ft) *</label>
                                            <input type="number" name="height" required class="input-field" placeholder="e.g. 3">
                                        </div>
                                    </div>
                                    <div style="margin-bottom:1rem;">
                                        <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Finish Type *</label>
                                        <select name="finish_type" required class="input-field">
                                            <option value="Matte">Matte</option>
                                            <option value="Glossy" selected>Glossy</option>
                                        </select>
                                    </div>
                                    <div style="margin-bottom:1rem;">
                                        <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">With Eyelets? *</label>
                                        <select name="with_eyelets" required class="input-field">
                                            <option value="Yes">Yes</option>
                                            <option value="No">No</option>
                                        </select>
                                    </div>

                                <?php elseif ($cat === 'T-Shirt Printing'): ?>
                                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem; margin-bottom:1rem;">
                                        <div>
                                            <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Size *</label>
                                            <select name="size" required class="input-field">
                                                <option value="S">S</option>
                                                <option value="M" selected>M</option>
                                                <option value="L">L</option>
                                                <option value="XL">XL</option>
                                            </select>
                                        </div>
                                        <div>
                                            <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Color *</label>
                                            <select name="color" required class="input-field">
                                                <option value="Black">Black</option>
                                                <option value="White" selected>White</option>
                                                <option value="Red">Red</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div style="margin-bottom:1rem;">
                                        <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Print Placement *</label>
                                        <select name="placement" required class="input-field">
                                            <option value="Front">Front</option>
                                            <option value="Back">Back</option>
                                            <option value="Both">Both</option>
                                        </select>
                                    </div>

                                <?php elseif ($cat === 'Stickers'): ?>
                                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem; margin-bottom:1rem;">
                                        <div>
                                            <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Shape *</label>
                                            <select name="shape" required class="input-field">
                                                <option value="Circle">Circle</option>
                                                <option value="Rectangle">Rectangle</option>
                                                <option value="Custom">Custom</option>
                                            </select>
                                        </div>
                                        <div>
                                            <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Size (inches) *</label>
                                            <input type="text" name="size" required class="input-field" placeholder="e.g. 2x2">
                                        </div>
                                    </div>
                                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem; margin-bottom:1rem;">
                                        <div>
                                            <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Finish *</label>
                                            <select name="finish" required class="input-field">
                                                <option value="Glossy">Glossy</option>
                                                <option value="Matte">Matte</option>
                                            </select>
                                        </div>
                                        <div>
                                            <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Waterproof? *</label>
                                            <select name="waterproof" required class="input-field">
                                                <option value="Yes">Yes</option>
                                                <option value="No">No</option>
                                            </select>
                                        </div>
                                    </div>

                                <?php elseif ($cat === 'Glass/Wall/Frosted'): ?>
                                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem; margin-bottom:1rem;">
                                        <div>
                                            <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Width *</label>
                                            <input type="text" name="width" required class="input-field">
                                        </div>
                                        <div>
                                            <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Height *</label>
                                            <input type="text" name="height" required class="input-field">
                                        </div>
                                    </div>
                                    <div style="margin-bottom:1rem;">
                                        <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Installation Needed? *</label>
                                        <select name="installation" required class="input-field">
                                            <option value="Yes">Yes</option>
                                            <option value="No">No</option>
                                        </select>
                                    </div>

                                <?php elseif ($cat === 'Transparent Stickers'): ?>
                                    <div style="margin-bottom:1rem;">
                                        <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Size *</label>
                                        <input type="text" name="size" required class="input-field" placeholder="e.g. 2x2">
                                    </div>
                                    <div style="margin-bottom:1rem;">
                                        <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">With White Ink? *</label>
                                        <select name="white_ink" required class="input-field">
                                            <option value="Yes">Yes</option>
                                            <option value="No">No</option>
                                        </select>
                                    </div>

                                <?php elseif ($cat === 'Layout Service'): ?>
                                    <div style="margin-bottom:1rem;">
                                        <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Type of Layout *</label>
                                        <select name="layout_type" required class="input-field">
                                            <option value="Logo">Logo</option>
                                            <option value="Banner">Banner</option>
                                            <option value="Invitation">Invitation</option>
                                            <option value="Others">Others</option>
                                        </select>
                                    </div>
                                    <div style="margin-bottom:1rem;">
                                        <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Rush? *</label>
                                        <select name="rush" required class="input-field">
                                            <option value="No">No</option>
                                            <option value="Yes">Yes</option>
                                        </select>
                                    </div>

                                <?php elseif ($cat === 'Reflectorized'): ?>
                                    <div style="margin-bottom:1rem;">
                                        <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Size *</label>
                                        <input type="text" name="size" required class="input-field">
                                    </div>
                                    <div style="margin-bottom:1rem;">
                                        <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Material Type *</label>
                                        <input type="text" name="material" required class="input-field">
                                    </div>
                                    <div style="margin-bottom:1rem;">
                                        <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Installation? *</label>
                                        <select name="installation" required class="input-field">
                                            <option value="No">No</option>
                                            <option value="Yes">Yes</option>
                                        </select>
                                    </div>

                                <?php elseif ($cat === 'Stickers on Sintraboard'): ?>
                                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem; margin-bottom:1rem;">
                                        <div>
                                            <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Thickness *</label>
                                            <select name="thickness" required class="input-field">
                                                <option value="3mm">3mm</option>
                                                <option value="5mm">5mm</option>
                                            </select>
                                        </div>
                                        <div>
                                            <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Size *</label>
                                            <input type="text" name="size" required class="input-field">
                                        </div>
                                    </div>
                                    <div style="margin-bottom:1rem;">
                                        <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">With Stand? *</label>
                                        <select name="with_stand" required class="input-field">
                                            <option value="No">No</option>
                                            <option value="Yes">Yes</option>
                                        </select>
                                    </div>

                                <?php elseif ($cat === 'Sintraboard Standees'): ?>
                                    <div style="margin-bottom:1rem;">
                                        <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Size *</label>
                                        <input type="text" name="size" required class="input-field">
                                    </div>
                                    <div style="margin-bottom:1rem;">
                                        <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">With Stand? *</label>
                                        <select name="with_stand" required class="input-field">
                                            <option value="Yes">Yes</option>
                                            <option value="No">No</option>
                                        </select>
                                    </div>

                                <?php elseif ($cat === 'Souvenirs'): ?>
                                    <div style="margin-bottom:1rem;">
                                        <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Type *</label>
                                        <input type="text" name="type" required class="input-field" placeholder="Mug, Keychain, etc.">
                                    </div>
                                    <div style="margin-bottom:1rem;">
                                        <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Custom Print? *</label>
                                        <select name="custom_print" required class="input-field">
                                            <option value="Yes">Yes</option>
                                            <option value="No">No</option>
                                        </select>
                                    </div>
                                <?php endif; ?>

                                <!-- Common Fields -->
                                <div style="margin-top:1.5rem; padding-top:1.5rem; border-top:1px dashed #d1d5db;">
                                    <div style="margin-bottom:1rem;">
                                        <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">
                                            Upload Design/Reference (JPG/PNG/PDF) *
                                        </label>
                                        <input type="file" name="design_upload" required class="input-field" accept=".jpg,.jpeg,.png,.pdf" style="padding:0.4rem;">
                                        <p style="font-size:0.75rem; color:#6b7280; margin-top:4px;">Max size: 5MB</p>
                                    </div>

                                    <div style="margin-bottom:1rem;">
                                        <label style="display:block; font-size:0.875rem; font-weight:600; margin-bottom:0.4rem;">Additional Notes</label>
                                        <textarea name="notes" rows="2" class="input-field" placeholder="Any special instructions..."></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div style="margin-bottom:2rem;">
                            <label style="display:block; font-size:0.875rem; font-weight:700; color:#374151; margin-bottom:0.5rem;">Total Quantity</label>
                            <div style="display:flex; align-items:center; gap:12px;">
                                <button type="button" onclick="decrementQty()" style="width:44px; height:44px; border:1px solid #d1d5db; background:white; border-radius:8px; display:flex; align-items:center; justify-content:center; cursor:pointer; font-size:1.2rem; font-weight:600;">-</button>
                                <input type="number" name="quantity" id="quantity" value="1" min="1" max="<?php echo $product['stock_quantity']; ?>" style="width:70px; height:44px; text-align:center; border:1px solid #d1d5db; border-radius:8px; font-weight:600; font-size:1.1rem;">
                                <button type="button" onclick="incrementQty()" style="width:44px; height:44px; border:1px solid #d1d5db; background:white; border-radius:8px; display:flex; align-items:center; justify-content:center; cursor:pointer; font-size:1.2rem; font-weight:600;">+</button>
                                <span style="font-size:0.875rem; color:#6b7280; font-weight:500;"><?php echo $product['stock_quantity']; ?> items available</span>
                            </div>
                        </div>

                        <div style="display:grid; grid-template-columns:10fr 21fr; gap:1rem;">
                            <button type="submit" name="add_to_cart" value="1" class="btn-secondary" :disabled="!isValid" style="padding:1.1rem; font-weight:600; cursor:pointer; border-radius:10px; opacity: 1;" :style="!isValid ? 'opacity:0.5; cursor:not-allowed' : ''">Add to Cart</button>
                            <button type="submit" name="buy_now" value="1" class="btn-primary" :disabled="!isValid" style="padding:1.1rem; font-weight:600; cursor:pointer; border-radius:10px; opacity: 1;" :style="!isValid ? 'opacity:0.5; cursor:not-allowed' : ''">BUY IT NOW</button>
                        </div>
                        
                        <p x-show="!isValid" style="color:#ef4444; font-size:0.75rem; margin-top:10px; text-align:center; font-weight:500;">
                            Please fill out all required fields and upload a design to proceed.
                        </p>
                    </form>
                <?php else: ?>
                    <div style="padding:1rem; background:#fee2e2; color:#991b1b; border-radius:8px; text-align:center; font-weight:600;">
                        Out of Stock
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
    function incrementQty() {
        const input = document.getElementById('quantity');
        const max = parseInt(input.getAttribute('max'));
        let val = parseInt(input.value);
        if (val < max) {
            input.value = val + 1;
        }
    }
    
    function decrementQty() {
        const input = document.getElementById('quantity');
        let val = parseInt(input.value);
        if (val > 1) {
            input.value = val - 1;
        }
    }
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
